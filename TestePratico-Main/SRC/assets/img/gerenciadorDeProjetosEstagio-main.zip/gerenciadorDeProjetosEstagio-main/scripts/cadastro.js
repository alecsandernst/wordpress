
document.getElementById('register-form').addEventListener('submit', function(e) {
  e.preventDefault();
  
  const newUser = document.getElementById('new-username').value;
  const newPassword = document.getElementById('new-password').value;

 
  let users = JSON.parse(localStorage.getItem('users')) || [];

  const userExists = users.some(user => user.username === newUser);

  if (!userExists) {
      
      users.push({ username: newUser, password: newPassword });
      localStorage.setItem('users', JSON.stringify(users));
      alert('Usuário registrado com sucesso!');
      location.href = 'login.html'
  } else {
      alert('Usuário já consta no sistema');
  }
});



